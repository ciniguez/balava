package modelo.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the DOCENTE database table.
 * 
 */
@Entity
@NamedQuery(name="Docente.findAll", query="SELECT d FROM Docente d")
public class Docente implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PRO_ID", nullable = false)
	private Integer id;

	@Column(name="PRO_NUM_OFICINA", nullable = true)
	private int numero_oficina;

	//bi-directional many-to-one association to Departamento
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name="DEP_CODIGO", nullable = false)
	private Departamento departamento;

	//bi-directional many-to-one association to Usuario
	@ManyToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name="USU_ID", nullable = false)
	private Usuario usuario;


	public Docente() {
	}


	public Docente( int numero_oficina, Departamento departamento, Usuario usuario) {
		this.numero_oficina = numero_oficina;
		this.departamento = departamento;
		this.usuario = usuario;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	public int getNumero_oficina() {
		return numero_oficina;
	}


	public void setNumero_oficina(int numero_oficina) {
		this.numero_oficina = numero_oficina;
	}


	public Departamento getDepartamento() {
		return departamento;
	}


	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}


	public Usuario getUsuario() {
		return usuario;
	}


	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}


	@Override
	public String toString() {
		return this.usuario.toString();
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not set
		if (!(object instanceof Docente)) {
			return false;
		}
		Docente other = (Docente) object;
		if ((this.id == null && other.id != null)
				|| (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

}