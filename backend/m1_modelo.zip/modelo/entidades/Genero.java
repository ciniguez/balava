package modelo.entidades;

public enum Genero {
	FEMENINO ("Estudiante", 1),
	MASCULINO("Docente", 2);
	
	private String nombre;
	private int codigo;
	
	private Genero (String nombre, int codigo) {
		this.codigo = codigo;
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
}
