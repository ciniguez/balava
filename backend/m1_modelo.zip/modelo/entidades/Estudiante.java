package modelo.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ESTUDIANTE database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name="Estudiante.findAll", query="SELECT e FROM Estudiante e"),
})

public class Estudiante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="EST_ID", nullable=false)
	private Integer id;

	@Column(name="EST_CEDULA", nullable=false, length = 10)
	private String cedula;

	@Column(name="EST_GENERO", nullable = false)
	@Enumerated(value=EnumType.ORDINAL)
	private Genero genero;


	//bi-directional many-to-one association to Usuario
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name="USU_ID")
	private Usuario usuario;


	public Estudiante() {
	}


	public Estudiante(String cedula, Genero genero, Usuario usuario) {
		this.cedula = cedula;
		this.genero = genero;
		this.usuario = usuario;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getCedula() {
		return cedula;
	}


	public void setCedula(String cedula) {
		this.cedula = cedula;
	}


	public Genero getGenero() {
		return genero;
	}


	public void setGenero(Genero genero) {
		this.genero = genero;
	}


	public Usuario getUsuario() {
		return usuario;
	}


	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}



	@Override
	public String toString() {
		return this.usuario.toString()+ " - " + this.getCedula();
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not set
		if (!(object instanceof Estudiante)) {
			return false;
		}
		Estudiante other = (Estudiante) object;
		if ((this.id == null && other.id != null)
				|| (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}
	
	

}