package modelo.entidades;

public enum Perfil {
	ESTUDIANTE ("Estudiante", 1),
	DOCENTE("Docente", 2);
	
	private String nombre;
	private int codigo;
	
	private Perfil (String nombre, int codigo) {
		this.codigo = codigo;
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	
}
