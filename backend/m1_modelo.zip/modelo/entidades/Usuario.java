package modelo.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the USUARIO database table.
 * 
 */
@Entity
@NamedQuery(name="Usuario.findAll", query="SELECT u FROM Usuario u")
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="USU_ID", nullable = false)
	private Integer id;

	@Column(name="USU_CLAVE", nullable = false, length = 32)
	private String clave;

	@Column(name="USU_CORREO", nullable = false, length = 64)
	private String correo;

	@Column(name="USU_APELLIDO", nullable = false, length = 64)
	private String apellido;

	@Column(name="USU_NOMBRE", nullable = false, length = 64)
	private String nombre;
	
	@Column(name="US_PERFIL", nullable = false)
	@Enumerated (EnumType.ORDINAL)
	
	
	private Perfil perfil;

	public Usuario() {
	}

	public Usuario(String clave, String correo, String apellido, String nombre, Perfil perfil) {
		super();
		this.clave = clave;
		this.correo = correo;
		this.apellido = apellido;
		this.nombre = nombre;
		this.perfil = perfil;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getClave() {
		return clave;
	}


	public void setClave(String clave) {
		this.clave = clave;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public Perfil getPerfil() {
		return perfil;
	}


	public void setPerfil(Perfil perfil) {
		this.perfil = perfil;
	}


	@Override
	public String toString() {
		return "Usuario: "+this.correo;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not set
		if (!(object instanceof Usuario)) {
			return false;
		}
		Usuario other = (Usuario) object;
		if ((this.id == null && other.id != null)
				|| (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}
	
	
}