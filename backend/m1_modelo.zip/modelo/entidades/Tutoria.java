package modelo.entidades;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the TUTORIA database table.
 * 
 */
@Entity
@NamedQuery(name = "Tutoria.findAll", query = "SELECT t FROM Tutoria t")
public class Tutoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TUT_ID")
	private Integer id;

	// bi-directional many-to-one association to Estudiante
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "EST_ID", nullable = false)
	private Estudiante estudiante;

	// bi-directional many-to-one association to Docente
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "PRO_ID", nullable=false)
	private Docente docente;

	@Temporal(TemporalType.DATE)
	@Column(name = "TUT_FECHA", nullable = false)
	private Date tutFecha;

	@Column(name = "TUT_TEMA")
	private String tutTema;

	public Tutoria() {
	}

	public Tutoria(Estudiante estudiante, Docente docente, Date tutFecha, String tutTema) {
		this.estudiante = estudiante;
		this.docente = docente;
		this.tutFecha = tutFecha;
		this.tutTema = tutTema;
	}

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Estudiante getEstudiante() {
		return estudiante;
	}

	public void setEstudiante(Estudiante estudiante) {
		this.estudiante = estudiante;
	}

	public Docente getDocente() {
		return docente;
	}

	public void setDocente(Docente docente) {
		this.docente = docente;
	}

	public Date getTutFecha() {
		return tutFecha;
	}

	public void setTutFecha(Date tutFecha) {
		this.tutFecha = tutFecha;
	}

	public String getTutTema() {
		return tutTema;
	}

	public void setTutTema(String tutTema) {
		this.tutTema = tutTema;
	}

	@Override
	public String toString() {
		return "Tutoria - "+ this.id + "- (" + this.tutFecha.toString() + ")";
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not set
		if (!(object instanceof Tutoria)) {
			return false;
		}
		Tutoria other = (Tutoria) object;
		if ((this.id == null && other.id != null)
				|| (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}
	

}