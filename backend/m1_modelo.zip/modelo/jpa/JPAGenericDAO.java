package modelo.jpa;

import javax.persistence.EntityManagerFactory;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import modelo.dao.GenericDAO;

import java.util.List;

import javax.persistence.*;

public class JPAGenericDAO<T, ID> implements GenericDAO<T, ID> {

	protected EntityManager em;
	private Class<T> persistenceClass;

	public JPAGenericDAO(Class<T> persistenceCls) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistencia_1_JDBC");
		em = emf.createEntityManager();
		this.persistenceClass = persistenceCls;
	}

	@Override
	public void create(T entity) {
		em.getTransaction().begin();
		try {
			em.persist(entity);
			em.getTransaction().commit();

		} catch (Exception e) {
			System.out.println("Error en persist :" + e.getMessage());
			if (em.getTransaction().isActive())
				em.getTransaction().rollback();
		}
	}

	@Override
	public T read(ID id) {
		return em.find(persistenceClass, id);
	}

	@Override
	public void update(T entity) {
		em.getTransaction().begin();
		try {
			em.merge(entity);
			em.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("Error en merge-persistence: " + e.getMessage());
			if (em.getTransaction().isActive())
				em.getTransaction().rollback();
		}
	}

	@Override
	public void delete(T entity) {
		em.getTransaction().begin();
		try {
			em.remove(entity);
			em.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("Error en JPAGenericDAO-delete :" + e.getMessage());
			if (em.getTransaction().isActive())
				em.getTransaction().rollback();
		}
	}

	@Override
	public void deleteById(ID id) {
		try {
			T entity = this.read(id);
			if(entity!=null) {
				em.getTransaction().begin();
				em.remove(entity);
				em.getTransaction().commit();
			}	
		}catch(Exception e){
			System.out.println("Error en JPAGenericDAO - deleteById "+e.getMessage());
			if(em.getTransaction().isActive())
				em.getTransaction().rollback();
		}
		
	}

	@Override
	public List<T> findAll() {
		CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
		CriteriaQuery<T> criteriaQuery = criteriaBuilder
				.createQuery(this.persistenceClass);
		// Se establece la clausula FROM
		Root<T> root = criteriaQuery.from(this.persistenceClass);
		// Se establece la clausula SELECT
		criteriaQuery.select(root); // criteriaQuery.multiselect(root.get(atr))
		Query query = em.createQuery(criteriaQuery);
		return query.getResultList();
	}

}
