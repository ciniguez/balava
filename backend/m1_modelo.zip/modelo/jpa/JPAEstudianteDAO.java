package modelo.jpa;

import java.util.List;

import javax.persistence.Query;

import modelo.dao.EstudianteDAO;
import modelo.entidades.Estudiante;

public class JPAEstudianteDAO extends JPAGenericDAO<Estudiante, Integer> implements EstudianteDAO {


	public JPAEstudianteDAO() {
		super(Estudiante.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Estudiante> getEstudiantesPorCodigoMatricula(int codigoMatricula) {
		String queryString ="SELECT e FORM Estudiante e WHERE e.codigoUnico = :param1";
		Query query = em.createQuery(queryString);
		query.setParameter("param1", codigoMatricula);
		
		return query.getResultList();
	}

	@Override
	public List<Estudiante> getEstudiantesPorLetraApellido(String letra) {
		Query query = em.createNamedQuery("EstudiantesPorLetraApellido");
		@SuppressWarnings("unchecked")
		List<Estudiante> resultados = query.getResultList();
		return resultados;
	}

	@Override
	public List<Estudiante> getEstudiantesOrdeAlfabetico() {
		Query query = em.createNativeQuery("SELECT e.id, e.codigoUnico, e.nombre, e.apellido FROM Estudiante e ORDER BY e.apellido asc");
		@SuppressWarnings("unchecked")
		List<Estudiante> resultados = query.getResultList();
		return resultados;
	}


}
