package modelo.jpa;

import modelo.dao.TutoriaDAO;
import modelo.entidades.Tutoria;

public class JPATutoriaDAO extends JPAGenericDAO<Tutoria, Integer> implements TutoriaDAO {

	public JPATutoriaDAO() {
		super(Tutoria.class);
	}
	
}
