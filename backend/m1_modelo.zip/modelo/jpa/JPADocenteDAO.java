package modelo.jpa;

import modelo.dao.DocenteDAO;
import modelo.entidades.Docente;


public class JPADocenteDAO extends JPAGenericDAO<Docente, Integer> implements DocenteDAO {

	public JPADocenteDAO() {
		super(Docente.class);

	}
}
