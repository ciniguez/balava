package modelo.jpa;

import javax.persistence.Query;


import modelo.dao.UsuarioDAO;

import modelo.entidades.Usuario;

public class JPAUsuarioDAO extends JPAGenericDAO<Usuario, Integer> implements UsuarioDAO {

	public JPAUsuarioDAO() {
		super(Usuario.class);
	}

	@Override
	public Usuario auntenticar(String usuario, String clave) {
		System.out.println(usuario + " - " + clave);
		String queryString = "SELECT p FROM Usuario p WHERE p.correo =:correoPrm AND p.clave =:clavePrm";
		Query query = em.createQuery(queryString);
		
		query.setParameter("correoPrm", usuario);
		query.setParameter("clavePrm", clave);
		
		return (Usuario)query.getSingleResult();
		
	}

}
