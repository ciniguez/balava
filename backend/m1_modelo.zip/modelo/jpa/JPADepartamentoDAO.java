package modelo.jpa;

import java.util.List;

import javax.persistence.TypedQuery;

import modelo.dao.DepartamentoDAO;
import modelo.entidades.Departamento;

public class JPADepartamentoDAO extends JPAGenericDAO<Departamento, Integer> implements DepartamentoDAO {

	public JPADepartamentoDAO() {
		super(Departamento.class);
	}

	@Override
	public List<Departamento> findAll() {
		TypedQuery<Departamento> query =  em.createNamedQuery("Departamento.findAll", Departamento.class);
		return query.getResultList();
	}

}
