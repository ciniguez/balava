package modelo.jpa;

import modelo.dao.DAOFactory;
import modelo.dao.DepartamentoDAO;
import modelo.dao.EstudianteDAO;
import modelo.dao.DocenteDAO;
import modelo.dao.TutoriaDAO;
import modelo.dao.UsuarioDAO;

public class JPADAOFactory extends DAOFactory {

	@Override
	public EstudianteDAO getEstudianteDAO() {
		return new JPAEstudianteDAO();
	}

	@Override
	public DocenteDAO getDocenteDAO() {
		return new JPADocenteDAO();
	}

	@Override
	public TutoriaDAO getTutoriaDAO() {
		return new JPATutoriaDAO();
	}


	@Override
	public DepartamentoDAO getDepartamentoDAO() {
		return new JPADepartamentoDAO();
	}

	@Override
	public UsuarioDAO getUsuarioDAO() {
		return new JPAUsuarioDAO();
	}
}
