package modelo.dao;

import java.util.List;

import modelo.entidades.Estudiante;

public interface EstudianteDAO extends GenericDAO<Estudiante, Integer> {
	public List<Estudiante> getEstudiantesPorCodigoMatricula(int codigoMatricula);
	public List<Estudiante> getEstudiantesPorLetraApellido(String letra);
	public List<Estudiante> getEstudiantesOrdeAlfabetico();
	

}
