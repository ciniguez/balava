package modelo.dao;

import modelo.jpa.JPADAOFactory;

public abstract class DAOFactory {
	protected static DAOFactory factory = new JPADAOFactory();
	
	public static DAOFactory getFactory() {
		return factory;
	}
	public abstract EstudianteDAO getEstudianteDAO();
	public abstract DocenteDAO getDocenteDAO();
	public abstract TutoriaDAO getTutoriaDAO();
	public abstract UsuarioDAO getUsuarioDAO();
	public abstract DepartamentoDAO getDepartamentoDAO();
	
	

}
