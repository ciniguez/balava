package modelo.dao;

import modelo.entidades.Docente;

public interface DocenteDAO extends GenericDAO<Docente, Integer> {

}
