package modelo.dao;

import modelo.entidades.Departamento;

public interface DepartamentoDAO extends GenericDAO<Departamento, Integer> {

}
