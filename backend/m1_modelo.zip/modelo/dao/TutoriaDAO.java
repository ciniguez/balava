package modelo.dao;

import modelo.entidades.Tutoria;

public interface TutoriaDAO extends GenericDAO<Tutoria, Integer> {

}
