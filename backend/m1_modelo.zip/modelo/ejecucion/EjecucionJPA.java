package modelo.ejecucion;

import java.util.Calendar;

import modelo.entidades.Departamento;
import modelo.entidades.Docente;
import modelo.entidades.Estudiante;
import modelo.entidades.Genero;
import modelo.entidades.Perfil;
import modelo.entidades.Tutoria;
import modelo.entidades.Usuario;
import modelo.jpa.JPADAOFactory;

public class EjecucionJPA {

	public static void main(String[] args) {
		
		//Creación de Usuarios
		Usuario userEstudiante1 = new Usuario("est111","ismael.rivas@epn.edu.ec", "RIVAS","ISMAEL",Perfil.ESTUDIANTE);
		Usuario userEstudiante2 = new Usuario("est112","daniela.sevilla@epn.edu.ec", "SEVILLA","DANIELA",Perfil.ESTUDIANTE);
		Usuario userProfesor = new Usuario("pro123", "maria.hallo@epn.edu.ec", "HALLO", "MARIA", Perfil.DOCENTE);
		
		//Creación de Departamento
		Departamento dep = new Departamento("INTERACCION HUMANO COMPUTADOR");
		
		//Creación de Estudiantes y Profesores
		Estudiante estudiante1 = new Estudiante("1719477360", Genero.MASCULINO, userEstudiante1);
		Docente docente1 = new Docente(2005, dep, userProfesor);
		
		
		//JPADAOFactory.getFactory().getDocenteDAO().create(docente1);
		//JPADAOFactory.getFactory().getEstudianteDAO().create(estudiante1);
		
		
		Calendar fecha = Calendar.getInstance();
		fecha.set(2020, 8, 20, 16, 30);
		
		Tutoria tutoria1 = new Tutoria(estudiante1,docente1,fecha.getTime(),"Estilos y Paradigmas de interacción");
		JPADAOFactory.getFactory().getTutoriaDAO().create(tutoria1);
		
		//Insercion de estudiante Mujer
		Estudiante estudiante2 = new Estudiante("1719477370", Genero.FEMENINO, userEstudiante2);
		JPADAOFactory.getFactory().getEstudianteDAO().create(estudiante2);
		
		
	}
		

}
