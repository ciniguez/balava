package modelo.ejecucion;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Principal {

	public static void main(String[] args) throws SQLException {
		ConexionBDD cnn = new ConexionBDD();
		
		/**
		 * CONSULTAR
		 */
		ResultSet res =  cnn.consultar("SELECT * FROM CATEGORIA");
		try {
			while(res.next()) {
				System.out.println(res.getString("CAT_NOMBRE"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		/**
		 * INSERTAR
		 */
		boolean exito = cnn.ejecutarSQL("INSERT INTO CATEGORIA(CAT_NOMBRE) VALUES ('ROPA DE PLAYA')");
		if(exito) {
			System.out.println("Registro insertado");
		}
		
		res.close();
		res= null;
		cnn.cerrarConexion();
		
	}

}
