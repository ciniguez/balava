<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paises</title>
</head>
<body>
    <h1>Pasises de: NOMBRE CONTINENTE</h1>
    <p><a href="">Regresar a Continentes</a> | <a href="">Crear País</a></p>
    <table>
        <tr>
            <td>Pais</td>
            <td>Opciones</td>
        </tr>
        <tr>
            <td>SUDAN</td>
            <td><a href="">actualizar</a> | <a href="">eliminar</a></td>
        </tr>
    </table>
</body>
</html>