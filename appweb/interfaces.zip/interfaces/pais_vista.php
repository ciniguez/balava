<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pais</title>
</head>
<body>
    <h1>País</h1>
    <p><a href="">Regresar a Continentes</a></p>
    <form action="pais_insertar.php" method="POST">
    <p>Continente: AQUI CONTINENTE<br>
    <label for="txtnombre">Nombre País:</label><br>
    <input type="text" name="txtnombre"><br>
    <input type="submit" value="Guardar"/>
    </form>
</body>
</html>