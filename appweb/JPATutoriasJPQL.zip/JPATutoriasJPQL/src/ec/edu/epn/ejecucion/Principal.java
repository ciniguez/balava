package ec.edu.epn.ejecucion;

public class Principal {

	public static void main(String[] args) {
		//Aqui escribir la lógica para probar las consultas
		
		

	}

}
