package ec.edu.epn.modelo.jpa;

import ec.edu.epn.modelo.dao.DepartamentoDAO;
import ec.edu.epn.modelo.entity.Departamento;

public class JPADepartamentoDAO extends JPAGenericDAO<Departamento, Integer> implements
		DepartamentoDAO {

	public JPADepartamentoDAO() {
		super(Departamento.class);
		// TODO Auto-generated constructor stub
	}

	

}
