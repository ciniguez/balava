package ec.edu.epn.modelo.dao;

import ec.edu.epn.modelo.entity.Departamento;

public interface DepartamentoDAO extends GenericDAO<Departamento, Integer> {

}
