package ec.edu.epn.modelo.dao;

import ec.edu.epn.modelo.entity.Tutoria;

public interface TutoriaDAO extends GenericDAO<Tutoria, Integer> {

}
