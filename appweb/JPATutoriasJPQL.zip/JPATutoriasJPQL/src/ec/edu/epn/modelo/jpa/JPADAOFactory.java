 package ec.edu.epn.modelo.jpa;

import ec.edu.epn.modelo.dao.DAOFactory;
import ec.edu.epn.modelo.dao.DepartamentoDAO;
import ec.edu.epn.modelo.dao.EstudianteDAO;
import ec.edu.epn.modelo.dao.ProfesorDAO;
import ec.edu.epn.modelo.dao.TutoriaDAO;


public class JPADAOFactory extends DAOFactory {

	@Override
	public EstudianteDAO getEstudianteDAO() {
		return new JPAEstudianteDAO();
	}

	@Override
	public ProfesorDAO getProfesorDAO() {
		return new JPAProfesorDAO();
	}

	@Override
	public DepartamentoDAO getDepartamentoDAO() {
		return new JPADepartamentoDAO();
	}

	@Override
	public TutoriaDAO getTutoriaDAO() {
		return new JPATutoriaDAO();
	}


}
