package ec.edu.epn.modelo.dao;

import ec.edu.epn.modelo.entity.Estudiante;

public interface EstudianteDAO extends GenericDAO<Estudiante, Integer> {

	//Aqui escribir los Métodos de Negocio

}
