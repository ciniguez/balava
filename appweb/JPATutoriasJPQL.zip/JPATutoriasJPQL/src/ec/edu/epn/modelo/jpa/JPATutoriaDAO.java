package ec.edu.epn.modelo.jpa;

import ec.edu.epn.modelo.dao.TutoriaDAO;
import ec.edu.epn.modelo.entity.Tutoria;

public class JPATutoriaDAO extends JPAGenericDAO<Tutoria, Integer> implements TutoriaDAO {

	public JPATutoriaDAO() {
		super(Tutoria.class);
		// TODO Auto-generated constructor stub
	}

}
