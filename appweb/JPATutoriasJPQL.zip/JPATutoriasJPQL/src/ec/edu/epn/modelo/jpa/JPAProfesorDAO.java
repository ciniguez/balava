package ec.edu.epn.modelo.jpa;

import ec.edu.epn.modelo.dao.ProfesorDAO;
import ec.edu.epn.modelo.entity.Profesor;

public class JPAProfesorDAO extends JPAGenericDAO<Profesor, Integer> implements ProfesorDAO {

	public JPAProfesorDAO() {
		super(Profesor.class);
		// TODO Auto-generated constructor stub
	}

	
}
