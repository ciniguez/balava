package ec.edu.epn.modelo.dao;

import ec.edu.epn.modelo.entity.Profesor;

public interface ProfesorDAO extends GenericDAO<Profesor, Integer> {

}
