package ec.edu.epn.modelo.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Prueba
 *
 */
@Entity

public class Prueba implements Serializable {

	
	private static final long serialVersionUID = 1L;

	public Prueba() {
		super();
	}
   
}
