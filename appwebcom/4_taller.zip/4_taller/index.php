<?php
#ciniguez17
$cookie_nombre="";
$cookie_clave="";
$bandera = false;
if(isset($_COOKIE["recordar"])){
    echo "Cookie seteada<br>";
    $datosCookie= explode(";", $_COOKIE["recordar"]);
    $cookie_nombre = explode(":",$datosCookie[0])[1];
    $cookie_clave = explode(":",$datosCookie[1])[1];
    echo "Cookie: nombre: $cookie_nombre clave: $cookie_clave"."<br>";
    $bandera=true;
}

?>



<html>
    <head>
        <title>Mi sistema</title>
    </head>
    <body>
        <h1>LOGIN</h1>
        <form action="autorizar.php" method="POST">
            <!-- ciniguez17 -->
            Usuario:<br>
            <input type="text" name="nombre" value="<?php if($bandera){echo $cookie_nombre;}else{echo "";} ?>"/><br>
            Clave:<br>
            <input type="password" name="clave" value="<?php if($bandera){echo $cookie_clave;}else{echo "";} ?>"/><br>
            <input type="checkbox" name="chkRecordarme" <?php if($bandera){echo "checked";}?>>Recordarme</input><br>
            <!-- ciniguez17_fin -->
            <input type="submit" name="btnEnviar"/>
        </form>
    </body>
</html>