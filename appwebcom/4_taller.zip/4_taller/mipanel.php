<?php
#crear sesión o reiniciar una preexistente
session_start();

#Validar que las sesiones existen y no son vacías (También para SESSION[clave])
if($_SESSION["nombre"]=="" || $_SESSION["nombre"]== null){
    header("Location:index.php");
}

$idioma= "es";
if(isset($_GET['lang'])){
    setcookie("lang",$_GET['lang'],time()+(60*60*24));
    $idioma = $_GET['lang'];
}else{
    if(isset($_COOKIE['lang'])){
        $idioma = $_COOKIE['lang'];
    }
}

?>

<html>
    <head>
    </head>
    <body>
        <h1>PANEL PRINCIPAL</h1>
        <h3>Bienvenido Usuario: <?php echo $_SESSION["nombre"];  ?></h3>
        <p><a href="mipanel.php?lang=es">ES (Español)</a>|<a href="mipanel.php?lang=en"> EN (English)</a></p>
        <p><a href="cerrarsesion.php">Cerrar Sesion</a></p>
        

        
        <?php 
            $nombre_fichero = null;
            if($idioma=="es"){
                $nombre_fichero ="categorias_es.txt"; 
                echo "<h2>Lista de Productos</h2>";
            }else{
                $nombre_fichero ="categorias_en.txt";
                echo "<h2>Product List</h2>"; 
            }
            
            $fichero = fopen($nombre_fichero, "r");
            while (!feof($fichero)){
                $linea = fgets($fichero);
                echo $linea."<br>";
            }
            fclose ($fichero);
        ?>
    </body>
</html>