<?php

#para iniciar sesión se usa session_start()
session_start();

if(isset($_POST)){
    $_SESSION['nombre'] = $_POST["nombre"];
    $_SESSION['clave'] = $_POST["clave"];
    #agregado
    var_dump($_POST);

    if(isset($_POST["chkRecordarme"])){
        if($_POST["chkRecordarme"]==true){
            $cookie_valor="nombre:".$_POST['nombre'].";clave:".$_POST['clave'];
            setcookie("recordar",$cookie_valor,time()+(60*60*24),"/","localhost");
            echo "Cookie seteada <br>";
        }
    }else{
        if(isset($_COOKIE["recordar"])){
            setcookie("recordar","",time()-(60*60*24),"/","localhost");
            echo "Cookie eliminada <br>";
        }else{
            echo "Cookie no se elimino porque no está seteada <br>";
        }
    }
    #fin_agregado
    header("Location:mipanel.php");
}else{
    header("Location:index.php");
}

?>